import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Creates a Scanner object that reads from the standard input
        ArrayList<String> tasks = new ArrayList<>(); // Creates an ArrayList to store the tasks

        File file = new File("todolist.txt"); // Creates a File object to represent the todolist.txt file
        try (Scanner fileScanner = new Scanner(file)) { // Tries to read the contents of the file using a Scanner
            while (fileScanner.hasNextLine()) {
                tasks.add(fileScanner.nextLine()); // Adds each line of the file to the ArrayList
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }

        int choice;
        do {
            System.out.println("1. Add a new task");
            System.out.println("2. Edit task");
            System.out.println("3. Mark task as done");
            System.out.println("4. Clear task list");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("Enter task: ");
                    String task = scanner.nextLine();
                    try (FileWriter writer = new FileWriter("todolist.txt", true)) {
                        writer.write(task + "\n"); // Writes the new task to the file
                        System.out.println("Task added.");
                    } catch (IOException e) { //Catches the exception if there is an error writing to the file
                        System.out.println("Error adding task.");
                    }
                    break;
                case 2:
                    System.out.print("Enter line number to clear: ");
                    int lineNum = scanner.nextInt();

                    String content = "";
                    try (Scanner fileScanner = new Scanner(file)) {
                        int currentLine = 1;
                        while (fileScanner.hasNextLine()) {
                            if (currentLine != lineNum) {
                                content += fileScanner.nextLine() + "\n"; // Adds the current line to the `content` string, unless it is the line to be cleared
                            } else {
                                fileScanner.nextLine();
                            }
                            currentLine++;
                        }
                    } catch (FileNotFoundException e) {
                        System.out.println("File not found.");
                    }
                    try (FileWriter writer = new FileWriter("todolist.txt")) {
                        writer.write(content);
                        System.out.println("Task cleared.");
                    } catch (IOException e) {
                        System.out.println("Error clearing task.");
                    }
                    break;

                case 3:
                    System.out.print("Enter line number of the task to mark as done: ");
                    lineNum = scanner.nextInt();
                    scanner.nextLine();
                    if (lineNum > 0 && lineNum <= tasks.size()) {
                        content = "";
                        try (Scanner fileScanner = new Scanner(file)) {
                            int currentLine = 1;
                            while (fileScanner.hasNextLine()) {
                                if (currentLine != lineNum) {
                                    content += fileScanner.nextLine() + System.lineSeparator();
                                } else {
                                    content += fileScanner.nextLine() + " - done" + System.lineSeparator();
                                }
                                currentLine++;
                            }
                        } catch (FileNotFoundException e) {
                            System.out.println("File not found.");
                        }
                        try (FileWriter writer = new FileWriter("todolist.txt")) {
                            writer.write(content);
                            System.out.println("Task marked as done.");
                        } catch (IOException e) {
                            System.out.println("Error marking task as done.");
                        }
                    }
                    break;

                case 4:
                    try (FileWriter writer = new FileWriter("todolist.txt")) {
                        writer.write("");
                        System.out.println("Task list cleared.");
                    } catch (IOException e) {
                        System.out.println("Error clearing task list.");
                    }
                    break;
                case 5:
                    System.out.println("Goodbye!");
                    break;
            }
        } while (choice != 5);
    }
}
