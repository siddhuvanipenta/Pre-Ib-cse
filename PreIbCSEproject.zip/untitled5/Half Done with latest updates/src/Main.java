import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> tasks = new ArrayList<>();

        File file = new File("todolist.txt");
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                tasks.add(fileScanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }

        int choice;
        do {
            System.out.println("1. Add a new task");
            System.out.println("2. Edit task");
            System.out.println("3. Mark task as done");
            System.out.println("4. Clear task list");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("Enter task: ");
                    String task = scanner.nextLine();
                    try (FileWriter writer = new FileWriter("todolist.txt", true)) {
                        writer.write(task + "\n");
                        System.out.println("Task added.");
                    } catch (IOException e) {
                        System.out.println("Error adding task.");
                    }
                    break;
                case 2:
                    System.out.print("Enter line number to edit: ");
                    int lineNum = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new task: ");
                    task = scanner.nextLine();
                    try (FileWriter writer = new FileWriter("todolist.txt")) {
                        for (int i = 0; i < tasks.size(); i++) {
                            if (i == lineNum - 1) {
                                writer.write(task + "\n");
                            } else {
                                writer.write(tasks.get(i) + "\n");
                            }
                        }
                        System.out.println("Task edited.");
                    } catch (IOException e) {
                        System.out.println("Error editing task.");
                    }
                    break;
                case 3:
                    System.out.print("Enter line number of the task to mark as done: ");
                    lineNum = scanner.nextInt();
                    scanner.nextLine();
                    if (lineNum > 0 && lineNum <= tasks.size()) {
                        try (FileWriter writer = new FileWriter("todolist.txt")) {
                            for (int i = 0; i < tasks.size(); i++) {
                                if (i != lineNum - 1) {
                                    writer.write(tasks.get(i) + "\n");
                                }
                            }
                            System.out.println("Task marked as done.");

