import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("1. Add a new task");
            System.out.println("2. Edit task");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("Enter task: ");
                    String task = scanner.nextLine();
                    try {
                        FileWriter writer = new FileWriter("todolist.txt", true);
                        writer.write(task + "\n");
                        writer.close();
                        System.out.println("Task added.");
                    } catch (IOException e) {
                        System.out.println("Error adding task.");
                    }
                    break;
                case 2:
                    System.out.print("Enter line number to edit: ");
                    int lineNum = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new task: ");
                    task = scanner.nextLine();
                    try {
                        // code to edit task at line number 'lineNum'
                    } catch (Exception e) {
                        System.out.println("Error editing task.");
                    }
                    break;
                case 3:
                    System.out.println("Exiting.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 3);
        scanner.close();
    }
}
